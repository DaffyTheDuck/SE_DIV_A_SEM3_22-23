# Mini-Project-1A
 
# Topic Selected
Bug Tracking System 🐞


## 📷 UI Screenshots 📷

![Login Page](https://github.com/DaffyTheDuck/Mini-Project-1A/blob/main/src/images/Login%20Page.PNG)

-----------

![Home Page](https://github.com/DaffyTheDuck/Mini-Project-1A/blob/main/src/images/Home%20Page.PNG)

-----------

![New Bug Page](https://github.com/DaffyTheDuck/Mini-Project-1A/blob/main/src/images/New%20Bug.PNG)
